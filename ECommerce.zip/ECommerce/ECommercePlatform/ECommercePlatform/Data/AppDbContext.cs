using Microsoft.EntityFrameworkCore;  // Required to work with Entity Framework
using ECommercePlatform.Models;      // Reference to your Models (Product, User, Order)

public class AppDbContext : DbContext
{
    // DbSet properties for each model (Product, User, Order)
    public DbSet<Product> Products { get; set; }
    public DbSet<User> Users { get; set; }
    public DbSet<Order> Orders { get; set; }

    // Constructor that takes DbContextOptions
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
}
