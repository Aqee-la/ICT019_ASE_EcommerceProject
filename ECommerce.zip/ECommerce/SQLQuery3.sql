SELECT * FROM Customers;
