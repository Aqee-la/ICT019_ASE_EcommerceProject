SELECT * FROM Products;
