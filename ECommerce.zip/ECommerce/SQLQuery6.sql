SELECT * FROM OrderItems;
