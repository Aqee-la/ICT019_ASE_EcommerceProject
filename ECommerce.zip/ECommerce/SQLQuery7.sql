SELECT * FROM Payments;
